/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
	//GPIO_TypeDef htim
//GPIO_TypeDef htim
//GPIO_PinState botao
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
#define max 9
#define min 0
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
	uint8_t contaO=0;
	uint8_t contaN=0;
	uint8_t aux=0;
	uint8_t trava1=0;
	uint8_t trava2=0;


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);

//FUNÇÃO PARA LIGAMENTO DE LEDS
void AO(void){
	HAL_GPIO_WritePin(A_GPIO_Port, A_Pin, GPIO_PIN_SET);
}
void BO(void){
	HAL_GPIO_WritePin(B_GPIO_Port, B_Pin, GPIO_PIN_SET);
}
void CO(void){
	HAL_GPIO_WritePin(C_GPIO_Port, C_Pin, GPIO_PIN_SET);
}
void DO(void){
	HAL_GPIO_WritePin(D_GPIO_Port, D_Pin, GPIO_PIN_SET);
}
void EO(void){
	HAL_GPIO_WritePin(E_GPIO_Port, E_Pin, GPIO_PIN_SET);
}
void FO(void){
	HAL_GPIO_WritePin(F_GPIO_Port, F_Pin, GPIO_PIN_SET);
}
void GO(void){
	HAL_GPIO_WritePin(G_GPIO_Port, G_Pin, GPIO_PIN_SET);
}
//////////////////////////////////////////////////////////
//FUNÇÃO PARA DESLIGAMENTO DE LEDS
void AN(void){
	HAL_GPIO_WritePin(A_GPIO_Port, A_Pin, GPIO_PIN_RESET);
}
void BN(void){
	HAL_GPIO_WritePin(B_GPIO_Port, B_Pin, GPIO_PIN_RESET);
}
void CN(void){
	HAL_GPIO_WritePin(C_GPIO_Port, C_Pin, GPIO_PIN_RESET);
}
void DN(void){
	HAL_GPIO_WritePin(D_GPIO_Port, D_Pin, GPIO_PIN_RESET);
}
void EN(void){
	HAL_GPIO_WritePin(E_GPIO_Port, E_Pin, GPIO_PIN_RESET);
}
void FN(void){
	HAL_GPIO_WritePin(F_GPIO_Port, F_Pin, GPIO_PIN_RESET);
}
void GN(void){
	HAL_GPIO_WritePin(G_GPIO_Port, G_Pin, GPIO_PIN_RESET);
}
//////////////////////////////////////////////////////////
//FUNÇÃO PARA DEFINIÇÃO DE PADRÕES DE SAÍDA
//NUMERAIS
void UM(void){
	AN();
	BO();
	CO();
	DN();
	EN();
	FN();
	GN();
}
void DOIS(void){
	AO();
	BO();
	CN();
	DO();
	EO();
	FN();
	GO();
}
void TRES(void){
	AO();
	BO();
	CO();
	DO();
	EN();
	FN();
	GO();
}
void QUATRO(void){
	AN();
	BO();
	CO();
	DN();
	EN();
	FO();
	GO();
}
void CINCO(void){
	AO();
	BN();
	CO();
	DO();
	EN();
	FO();
	GO();
}
void SEIS(void){
	AO();
	BN();
	CO();
	DO();
	EO();
	FO();
	GO();
}
void SETE(void){
	AO();
	BO();
	CO();
	DN();
	EN();
	FN();
	GN();
}
void OITO(void){
	AO();
	BO();
	CO();
	DO();
	EO();
	FO();
	GO();
}
void NOVE(void){
	AO();
	BO();
	CO();
	DO();
	EN();
	FO();
	GO();
}
void ZERO(void){
	AO();
	BO();
	CO();
	DO();
	EO();
	FO();
	GN();
}
//ALFABETO
void A(void){
	AO();
	BO();
	CO();
	DN();
	EO();
	FO();
	GO();
}
void B(void){
	AN();
	BN();
	CO();
	DO();
	EO();
	FO();
	GO();
}
void C(void){
	AN();
	BN();
	CN();
	DO();
	EO();
	FN();
	GO();
}
void D(void){
	AN();
	BO();
	CO();
	DO();
	EO();
	FN();
	GO();
}
void E(void){
	AO();
	BN();
	CN();
	DO();
	EO();
	FO();
	GO();
}
void F(void){
	AO();
	BN();
	CN();
	DN();
	EO();
	FO();
	GO();
}
void G(void){
	AO();
	BO();
	CO();
	DO();
	EN();
	FO();
	GO();
}
void H(void){
	AN();
	BN();
	CO();
	DN();
	EO();
	FO();
	GO();
}
void I(void){
	AN();
	BN();
	CO();
	DN();
	EN();
	FN();
	GN();
}
void J(void){
	AN();
	BO();
	CO();
	DO();
	EO();
	FN();
	GN();
}
void K(void){
	AN();
	BN();
	CN();
	DN();
	EO();
	FO();
	GO();
}
void L(void){
	AN();
	BN();
	CN();
	DO();
	EO();
	FO();
	GN();
}
void M(void){
	AO();
	BN();
	CO();
	DN();
	EO();
	FN();
	GO();
}
void N(void){
	AN();
	BN();
	CO();
	DN();
	EO();
	FN();
	GO();
}
void O(void){
	AN();
	BN();
	CO();
	DO();
	EO();
	FN();
	GO();
}
void P(void){
	AO();
	BO();
	CN();
	DN();
	EO();
	FO();
	GO();
}
void Q(void){
	AO();
	BO();
	CO();
	DN();
	EN();
	FO();
	GO();
}
void R(void){
	AN();
	BN();
	CN();
	DN();
	EO();
	FN();
	GO();
}
void S(void){
	AO();
	BN();
	CO();
	DO();
	EN();
	FO();
	GO();
}
void T(void){
	AN();
	BN();
	CN();
	DO();
	EO();
	FO();
	GO();
}
void U(void){
	AN();
	BN();
	CO();
	DO();
	EO();
	FN();
	GN();
}
void V(void){
	AN();
	BO();
	CO();
	DO();
	EO();
	FO();
	GN();
}
void W(void){
	AO();
	BN();
	CO();
	DO();
	EO();
	FN();
	GN();
}
void X(void){
	AN();
	BO();
	CO();
	DN();
	EO();
	FO();
	GO();
}
void Y(void){
	AN();
	BO();
	CO();
	DN();
	EN();
	FO();
	GO();
}
void Z(void){
	AO();
	BO();
	CN();
	DO();
	EO();
	FN();
	GO();
}

//int tabela[]={0x01,0x02,0x04........};
/////////////////////////
// ___________________ //
//|  _______A_______  |//
//| |               | |//
//| |F             B| |//
//| |               | |//
//|  _______G_______  |//
//| |               | |//
//| |E             C| |//
//| |               | |//
//| |________D______| |//
//|___________________|//
/////////////////////////
//G-F-E-D-C-B-A
//6-5-4-3-2-1-0 //PINO
//0-0-0-0-0-0-0 //DESLIGADO
//0-1-1-1-1-1-1//->0 // 0X3F
//0-0-0-0-1-1-0//->1 // 0X06
//1-0-1-1-0-1-1//->2 // 0X5B
//1-0-0-1-1-1-1//->3 // 0X4F
//1-1-0-0-1-1-0//->4 // 0X66
//1-1-0-1-1-0-1//->5 // 0X6D
//1-1-1-1-1-0-1//->6 // 0X7D
//0-0-0-0-1-1-1//->7 // 0X07
//1-1-1-1-1-1-1//->8 // 0X7F
//1-1-0-1-1-1-1//->9 // 0X6F

//ALFABETO-
//G-F-E-D-C-B-A
//6-5-4-3-2-1-0 //PINO
//0-0-0-0-0-0-0 //DESLIGADO
//1-1-1-0-1-1-1//-> a // 0X77
//1-1-1-1-1-0-0//-> b // 0X7C
//1-0-1-1-0-0-0//-> c // 0X58
//1-0-1-1-1-1-0//-> d // 0X5E
//1-1-1-1-0-0-1//-> e // 0X79
//1-1-1-0-0-0-1//-> f // 0X71
//1-1-0-1-1-1-1//-> g // 0X6F
//1-1-1-0-1-0-0//-> h // 0X74
//0-0-0-0-1-0-0//-> i // 0X04
//0-0-1-1-1-1-0//-> j // 0X1E
//1-1-1-0-0-0-0//-> k // 0X70
//0-1-1-1-0-0-0//-> l // 0X38
//1-0-1-0-1-0-1//-> m // 0X55
//1-0-1-0-1-0-0//-> n // 0X54
//1-0-1-1-1-0-0//-> o//  0X5C
//1-1-1-0-0-1-1//-> p // 0X73
//1-1-0-0-1-1-1//-> q // 0X67
//1-0-1-0-0-0-0//-> r // 0X50
//1-1-0-1-1-0-1//-> s // 0X6D
//1-1-1-1-0-0-0//-> t // 0X78
//0-0-1-1-1-0-0//-> u // 0X1C
//0-1-1-1-1-1-0//-> v // 0X3E
//0-0-1-1-1-0-1//-> w // 0X1D
//1-1-1-0-1-1-0//-> x // 0X76
//1-1-0-0-1-1-0//-> y // 0X66
//1-0-1-1-0-1-1//-> z // 0X5B

void delayt10(){
	  /* Wait for TIM10 update event flag */
	  while(__HAL_TIM_GET_FLAG(&htim10, TIM_FLAG_UPDATE) == RESET) {}

	  /* Clear TIM10 update event flag */
	  __HAL_TIM_CLEAR_FLAG(&htim10, TIM_FLAG_UPDATE);
}

void itfunction(void){
	//switch que decidira a função de saida dos leds a ser chamada dependendo do valor de aux
	switch(aux){
		case 0:
			ZERO();
			break;
		case 1:
			UM();
			break;
		case 2:
			DOIS();
			break;
		case 3:
			TRES();
			break;
		case 4:
			QUATRO();
			break;
		case 5:
			CINCO();
			break;
		case 6:
			SEIS();
			break;
		case 7:
			SETE();
			break;
		case 8:
			OITO();
			break;
		case 9:
			NOVE();
			break;
	}
	//checa se o pino de contagem positiva esta ligado e o de contagem negativa esta desligado
		if(HAL_GPIO_ReadPin(B1_GPIO_Port, B1_Pin)==GPIO_PIN_SET && HAL_GPIO_ReadPin(B2_GPIO_Port, B2_Pin)==GPIO_PIN_RESET){
			if(trava1==0){
							trava1=1;
							trava2=0;
							contaO=1;
							contaN=0;

			}
		}
		//checa se o pino de contagem negativa esta ligado e o de contagem positiva esta desligado
		if(HAL_GPIO_ReadPin(B2_GPIO_Port, B2_Pin)==GPIO_PIN_SET && HAL_GPIO_ReadPin(B1_GPIO_Port, B1_Pin)==GPIO_PIN_RESET){
			if(trava2==0){
							trava1=0;
							trava2=1;
							contaO=0;
							contaN=1;
						}
		}


}
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_TIM10_Init();
  MX_TIM11_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_Base_Start(&htim10);
  HAL_TIM_Base_Start_IT(&htim11);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  __HAL_TIM_SET_AUTORELOAD(&htim11, 999);
  __HAL_TIM_SET_AUTORELOAD(&htim10, 999);
  __HAL_TIM_SET_PRESCALER(&htim10, 41999);
  while (1)
  {
	  itfunction();
    /* USER CODE END WHILE */
	  //contara positivamente
	  if(contaO==1){
		  aux++;

			delayt10();
		  if(aux>max){
			  aux=0;
		  }
	  }
	  //mostrara zero na tela caso nao haja contagem
	  else{
		  ZERO();
	  }
	  //contara negativamente
	  if(contaN==1){
		  aux--;
			delayt10();
		  if(aux<min){
			  aux=9;
		  }
	  }
	  //mostrara zero na tela caso nao haja contagem
	  else{
		  ZERO();
	  }



    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{

	__HAL_TIM_CLEAR_IT(&htim11,TIM_IT_UPDATE);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
